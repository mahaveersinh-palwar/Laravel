<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Home Page</title>

    </head>
   <body>
        <?php echo $__env->make('Template.Navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('Home'); ?>
        <?php echo $__env->yieldContent('about'); ?>
        <?php echo $__env->yieldContent('Contact'); ?>

   </body>
</html>
<?php /**PATH D:\Mahaveersinh\first\resources\views///Template/Index.blade.php ENDPATH**/ ?>